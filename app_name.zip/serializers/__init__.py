from {{app_name}}.serializers import *
