from rest_framework.serializers import ModelSerializer


class BaseSerializer(ModelSerializer):
    class Meta:
        read_only_fields = [
            "id",
        ]
        abstract = True
