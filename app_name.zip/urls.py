from django.urls import path, include
from {{app_name}}.routes import router


urlpatterns = [
    path("", include(router.urls), name="{{app_name}}"),
]
