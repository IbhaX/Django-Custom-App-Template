from rest_framework.filters import BaseFilterBackend


class SortSearchFilterBackend(BaseFilterBackend):
    def filter_queryset(self, request, queryset, view):
        ordering = request.query_params.get("sort", None)
        search = request.query_params.get("search", None)
        if ordering:
            return queryset.order_by(ordering)
        if search:
            return queryset.filter(name__icontains=search)
        return queryset
