from django.db import models
from common.models import OneCareUser
from django.urls import reverse


class BaseModel(models.Model):
    status = models.BooleanField(default=True)
    created_by = models.ForeignKey(
        OneCareUser,
        on_delete=models.CASCADE,
        related_name="%(class)s_created_by",
        blank=True,
        null=True,
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_by = models.ForeignKey(
        OneCareUser,
        on_delete=models.CASCADE,
        related_name="%(class)s_updated_by",
        blank=True,
        null=True,
    )
    updated_at = models.DateTimeField(auto_now=True, blank=True, null=True)

    class Meta:
        abstract = True
